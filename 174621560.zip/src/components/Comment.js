function Comment(props) {
  const { text } = props;

  return <p>{text}</p>;
}

export default Comment;
